import csv
import random
import datetime


def print_menu(menuList):

    print("\n"*5)
    print("*" * 55)
    menu_title = "menu options"
    print(f"{menu_title.upper():^55}")
    print("*" * 55)
    for i in range(0, len(menuList)):
        print(f'{i+1}. {menuList[i]}')
       

def getMenuSelection(menuList):

    print_menu(menuList)
    choice = input("Type number to choose ... ")

    while choice not in ['1', '2', '3', '4', '5', '6', '7', '8']:
        print("Unknown selection")
        print("\n"*30)
       
        print_menu(menuList)
        choice = input("Type number to choose ... ")

    return int(choice)

def generate_costs(all_book_list):

    costs_list = []
    for b in range(0, len(all_book_list)):
        b = random.uniform(5, 10)
        b = round(b, 2)
        costs_list.append(b)
    return costs_list

def print_bill(all_book_list, payments_list, dmy):
    subtotal = 0

    s = f'{dmy.today().strftime("%a %b %d %Y")}'
    print("_" * 35)
    print(s)
    print("Your book charges:" +"\n" + "-" * 35)
    for i in range(0, len(all_book_list)):
        print(f"{all_book_list[i]} - ${payments_list[i]:.2f}")
        i+= 1
    print("-" * 35)
       
    for p in payments_list:
        subtotal += p
       
    tax = 0.13 * subtotal
    total = tax + subtotal
    print(f"Tax : ${tax:.2f}")
    print(f"Subtotal : ${subtotal:.2f}")
    print(f"Total : ${total:.2f}")
    print("-" * 35)
    due_date = datetime.datetime.today() + datetime.timedelta(days=30)
    due_date_formatted = due_date.strftime ("%a %b %d %Y") # format the date to ddmmyyyy
    print ('Total to be paid by: ' + str(due_date_formatted))
   
def print_all_books(book, all_book_list):
    print("*" * 55)
    print(f"You are currently reading : {book}")
    print("*" * 55)
    print("Your library :")
    print("-" * 55)
    for i in range(0, len(all_book_list)):
        print(f" {str(i+1)}. {all_book_list[i]}")

def change_preferred_book(all_book_list):
    choices_as_string = []
    for i in range(0, len(all_book_list)):
        choices_as_string.append(str(i+1))
       
    print("\n")
    choice = input("Which book do you want to read, now? Choose number: ")

    while choice not in (choices_as_string):
        choice = input("Invalid choice. Please enter a valid number: ")

    choice = int(choice) - 1
    return all_book_list[choice]
   

##def get_author_name(all_book_list, book):
##
##    num = all_book_list.index(book)
##    author_names = ["Agatha Christie", "Bram Stoker", "Mary Shelley", "Steven S. Skiena and Miguel A. Revilla", "Delia Owens"]
##    return author_names[num]
##
##def print_author_name(name):
##
##    print("* " * 10)
##    print(f"Author: {name}")
##    print("* " * 10)
##
##def get_genre(all_book_list, book):
##    num = all_book_list.index(book)
##    genres = ["Mystery", "Horror", "Horror", "Non-Fiction", "Mystery"]
##    return genres[num]
##
##def print_genre(g):
##
##    print(f"Genre: {g}")
##    print("* " * 10)
def get_book_information(all_book_list, book):
   
    num = all_book_list.index(book)
    return num

def print_book_information(info, all_book_list, all_author_list, all_genre_list, all_page_list, book):
   
    print("*" * 55)
    print(f"You are currently reading : {book}")
    print("*" * 55)
    print(f"Author : {all_author_list[info]}")
    print("~" * 55)
    print(f"Genre : {all_genre_list[info]}")
    print("~" * 55)
    print(f"Page Count : {all_page_list[info]}")
    print("~" * 55)

def take_second(elem):

    return elem[1]


def generate_series_list(all_series_list):
    series_title_list = []
    hp_list = []
    tq_list = []
    po_list = []
    hg_list = []

    for s in all_series_list:
        series_title = s[4]
        title_in_list = []
        if series_title in series_title_list:
            pass
        else:
            title_in_list.append(series_title)
            series_title_list.append(series_title)

##    for t in series_title_list:
##        series = [t]
##        views_amount = random.randint(500000, 2000000)
##        series.append(views_amount)
##        series_title_list.append(series)
##        
##    series_title_list.sort(key=take_second, reverse=True)
##    print(series_title_list)

    for l in all_series_list:
        series_title = l[4]
        if series_title == "Harry Potter Series":
            hp_list.append(l[0:4])
        elif series_title == "Time Quintlet Series":
            tq_list.append(l[0:4])
        elif series_title == "Percy Jackson & the Olympians Series":
            po_list.append(l[0:4])
        elif series_title == "The Hunger Games Series":
            hg_list.append(l[0:4])

    return series_title_list, hp_list, tq_list, po_list, hg_list

def divide_series_titles_in_lists(all_series_list):
    for i in range(0, len(all_series_list)):  
        yield all_series_list[i : i + 1]

def add_series_viewers(series_titles_in_lists):
   
    for n in series_titles_in_lists:
        num_of_views = random.randint(500000, 1500000)
        n.append(num_of_views)

    series_titles_in_lists.sort(key=take_second, reverse=True)
    return series_titles_in_lists

def print_series(all_series_list):
    print("*" * 55)
    title = "Popular Book Series"
    border = "-" * 55
    print(f"{title:^55}\n{border}")
    rank = 1

    for a in all_series_list:
        print(f"*#{str(rank)}* ~ {a[0]}")
        print("-" * 55)
        view_title = "* Number of customers who purchased the complete series\n  gift set : "

        display_views = ""
        use_views = str(a[1])
       
        if len(use_views) == 7:
            display_views += use_views[0]
            display_views += " "
            display_views += use_views[1:4]
            display_views += " "
            display_views += use_views[-3:]
            print(f"{view_title:>25}{display_views} Customer Purchases")
        elif len(use_views) == 6:
            display_views += use_views[0:3]
            display_views += " "
            display_views += use_views [-3:]
            print(f"{view_title:>25}{display_views} Customer Purchases")
        elif len(use_views) == 5:
            display_views += use_views[0:2]
            display_views += " "
            display_views += use_views [-3:]
            print(f"{view_title:>25}{display_views} Customer Purchases")
        elif len(use_views) == 4:
            display_views += use_views[0]
            display_views += " "
            display_views += use_views [-3:]
            print(f"{view_title:>25}{display_views} Customer Purchases")
        elif len(use_views) <= 3:
            for u in use_views:
                use_views += str(u)
            print(f"{view_title:>25}{display_views} Customer Purchases")
        print("_" * 55)

        display_views = ""
        use_views = ""
        rank += 1

def select_series_to_learn(all_series_list, series_with_views_list, hp_list, tq_list, po_list, hg_list):
    choices_as_string = []
   
    for i in range(0, len(all_series_list)):
        choices_as_string.append(str(i+1))
       
    print("\n")
    choice = input("Which series do you want to learn more about?\nChoose number: ")

    while choice not in (choices_as_string):
        choice = input("Invalid choice. Please try another number: ")

    choice = int(choice) - 1
    series_chosen = series_with_views_list[choice]
    print("*" * 55)
    print(f"{series_chosen[0].upper():^55}")
    print("*" * 55)
   
    if series_chosen[0] == "Harry Potter Series":
        hp = hp_list[0]
        hp_book_information = hp[1 : 3]
        return hp_book_information, hp_list
   
    elif series_chosen[0] == "Time Quintlet Series":
        tq = tq_list[0]
        tq_book_information = tq[1 : 3]
        return tq_book_information, tq_list

    elif series_chosen[0] == "Percy Jackson & the Olympians Series":
        po = po_list[0]
        po_book_information = po[1 : 3]
        return po_book_information, po_list

    elif series_chosen[0] == "The Hunger Games Series":
        hg = hg_list[0]
        hg_book_information = hg[1 : 3]
        return hg_book_information, hg_list
       
##    if series_chosen[0] == "Harry Potter Series":
##        hp = hp_list[0]
##        hp_book_information = hp[1 : 3]
##        author_t = "Author of Series : "
##        genre_t = "Genre of Series : "
##        print(f"{author_t:>30}{hp_book_information[0]}")
##        print(f"{genre_t:>30}{hp_book_information[1]}")
##        stars = "*" * 3
##        print(f"{stars:^55}")
##        for h in hp_list:
##            author = h[1]
##            genre = h[2]
##            h.remove(author)
##            h.remove(genre)
##
##        for p in range(0, len(hp_list)):
##            book = hp_list[p]
##            print(f"*** BOOK {p+1}. {book[0]} ***")
##            print("-" * 55)
##            pages = "~ Page Count: "
##            print(f"{pages:>15}{book[1]}")
##            print("_" * 55)

def print_series_books(general_series_info, books_in_chosen_series):
    author_t = "Author of Series : "
    genre_t = "Genre of Series : "
    print(f"{author_t:>30}{general_series_info[0]}")
    print(f"{genre_t:>30}{general_series_info[1]}")
    stars = "*" * 3
    print(f"{stars:^55}")
    for c in books_in_chosen_series:
        author = c[1]
        genre = c[2]
        c.remove(author)
        c.remove(genre)

    for h in range(0, len(books_in_chosen_series)):
        book = books_in_chosen_series[h]
        print(f"*** BOOK {h+1}. {book[0]} ***")
        print("-" * 55)
        pages = "~ Page Count: "
        print(f"{pages:>15}{book[1]}")
        print("_" * 55)

def take_fifth(elem):

    return elem[4]

def generate_trending_books(trendy_books_list):
   
    for t in trendy_books_list:
        num_of_views = random.randint(500000, 2000000)
        t.append(num_of_views)

    trendy_books_list.sort(key=take_fifth, reverse=True)
    return trendy_books_list

def print_trending_books(all_trendy_books_list):

    trending_title = "top trending books"
    print("-" * 55)
    print(f"{trending_title.upper():^55}")
    print("-" * 55)
    rank = 1

    for t in all_trendy_books_list:
        print(f"*#{str(rank)}* ~ {t[0]}")
        print("-" * 55)
        author = "* Author : "
        print(f"{author:>15}{t[1]}")
        genre = "* Genre : "
        print(f"{genre:>15}{t[2]}")
        page_number = "*Page Count : "
        print(f"{page_number:>15}{t[3]}")
        view_title = "* Views : "

        display_views = ""
        use_views = str(t[4])
       
        if len(use_views) == 7:
            display_views += use_views[0]
            display_views += " "
            display_views += use_views[1:4]
            display_views += " "
            display_views += use_views[-3:]
            print(f"{view_title:>15}{display_views} Views")
        elif len(use_views) == 6:
            display_views += use_views[0:3]
            display_views += " "
            display_views += use_views [-3:]
            print(f"{view_title:>15}{display_views} Views")
        elif len(use_views) == 5:
            display_views += use_views[0:2]
            display_views += " "
            display_views += use_views [-3:]
            print(f"{view_title:>15}{display_views} Views")
        elif len(use_views) == 4:
            display_views += use_views[0]
            display_views += " "
            display_views += use_views [-3:]
            print(f"{view_title:>15}{display_views} Views")
        elif len(use_views) <= 3:
            for u in use_views:
                use_views += str(u)
            print(f"{view_title:>15}{display_views} Views")
        print("_" * 55)

        display_views = ""
        use_views = ""
        rank += 1

def get_recommended_book_list(all_book_list, all_genre_list, book, programmer, detective, scary):

    book_num = all_book_list.index(book)
    genre = all_genre_list[book_num]
    if genre == "Mystery":
        return detective
    elif genre == "Horror":
        return scary
    elif genre == "Non-Fiction":
        return programmer
    else:
        recommendations = [programmer, detective, scary]
        return random.choice(recommendations)

def print_recommended_book_list(book, new_book_list):

    trending_title = "Recommended Books"
    print("-" * 55)
    print(f"{trending_title.upper():^55}")
    print("-" * 55)
    print(f"Based on what you're reading : {book} \nWe recommend...")
    print("_" * 55)

    for i in range(0, len(new_book_list)):
        current_book = new_book_list[i]
        print(f" {str(i+1)}. {current_book[0]}")
        author = "* Author : "
        print(f" {author:>20}{current_book[1]}")
        genre = "* Genre : "
        print(f" {genre:>20}{current_book[2]}")
        page_count = "* Page Count : "
        print(f" {page_count:>20}{current_book[3]}")
        match_percent = random.randint(90, 100)
        match = "* Compatibility : "
        print(f" {match:>20}{match_percent}% Match")
        print("-" * 55)

def add_book(all_book_list, all_author_list, all_genre_list, all_page_list, recommended):
    choices_as_string = []
    for i in range(0, len(recommended)):
        choices_as_string.append(str(i+1))
       
    print("\n")
    ask_user = input("Do you want to add a recommended book to your library? Type Yes or No.\n")
    while ask_user not in ["yes", "YES", "Yes", "y", "Y", "no", "NO", "No", "n", "N"]:
       
        ask_user = input("Sorry, I do not understand.\nPlease enter Yes if you want to read a recommended book \nor No if you do not want to read a recommended book.\n")
       
    if ask_user == "yes" or ask_user == "Yes" or ask_user == "YES" or ask_user == "Y" or ask_user == "y":
   
        choice = input("Which book do you want to add? Choose number: ")
       
        while choice not in (choices_as_string):
            choice = input("Invalid choice. Please try another number: ")

        choice = int(choice) - 1
        new_book = recommended[choice]
        all_book_list.append(new_book[0])
        all_book_list.sort()
        index = all_book_list.index(new_book[0])
        all_author_list.insert(index, new_book[1])
        all_genre_list.insert(index, new_book[2])
        all_page_list.insert(index, new_book[3])
       
    elif ask_user == "no" or ask_user == "No" or ask_user == "NO" or ask_user == "N" or ask_user == "n":
        print("That's okay! Maybe, next time :)")

##    for v in options_list:
##        if v != options_list[-1]:
##            response_rate = random.randint(0, remainder)
##            remainder -= response_rate
##            current_total += response_rate
##            print(response_rate)
##        elif v == options_list[-1]:
##            last = 100 - current_total
##            print(last)

def generate_shipments_with_days(all_shipment_books):
    for s in all_shipment_books:
        days_to_be_delivered = random.randint(1, 7)
        s.append(days_to_be_delivered)

    all_shipment_books.sort(key=take_fifth)
    return all_shipment_books

def print_shipments(books_to_be_shipped):
    shipment_title = "Your Hardcover Shipments"
    print("-" * 55)
    print("You can expect your hardcover book purchases to be delivered\nto your doorstep, in a week or less!")
    print(f"{shipment_title.upper():^55}")
    print("-" * 55)

    for h in books_to_be_shipped:
        print(f"*Book Title* ~ {h[0]}")
        print("-" * 55)
        author = "* Author : "
        print(f"{author:>18}{h[1]}")
        genre = "* Genre : "
        print(f"{genre:>17}{h[2]}")
        page_number = "* Page Count : "
        print(f"{page_number:>22}{h[3]}")
        delivery_date = "* It will arrive at your doorstep in: "
        print(f"{delivery_date:>45}*{h[4]} day(s)*")
        day_num = int(h[4])
        due_date = datetime.datetime.today() + datetime.timedelta(days=day_num)
        due_date_formatted = due_date.strftime ("%a %b %d %Y") # format the date to ddmmyyyy
        arrival_date = "Arrival Date : "
        print(f"{arrival_date:>24}{due_date_formatted}")
        print("-" * 55)

def alphabetize_shipments(books_to_be_shipped):
    print("\n")
    ask_user = input("To alpabetize shipments, type A: ")
    choices = ["A", "a", "yes", "YES", "Yes", "y", "Y", "no", "NO", "No", "n", "N"]
    while ask_user not in choices:
       
        ask_user = input("Sorry, I do not understand.\nPlease enter Yes if you want to alphabetize your book orders.\nor No if you do not want to alphabetize you book orders.\n")
           
    if ask_user in choices[0 : 7]:
        books_to_be_shipped.sort()
        for p in books_to_be_shipped:
            print(f"*Book Title* ~ {p[0]}")
            print("-" * 55)
            author = "* Author : "
            print(f"{author:>18}{p[1]}")
            genre = "* Genre : "
            print(f"{genre:>17}{p[2]}")
            page_number = "* Page Count : "
            print(f"{page_number:>22}{p[3]}")
            delivery_date = "* It will arrive at your doorstep in: "
            print(f"{delivery_date:>45}*{p[4]} day(s)*")
            day_num = int(p[4])
            due_date = datetime.datetime.today() + datetime.timedelta(days=day_num)
            due_date_formatted = due_date.strftime ("%a %b %d %Y") # format the date to ddmmyyyy
            arrival_date = "Arrival Date : "
            print(f"{arrival_date:>24}{due_date_formatted}")
            print("-" * 55)
    else:
        print("Your deliveries will arrive as soon as possible!\nOur staff is hard at work preparing them.")

def remove_book(all_book_list, all_author_list, all_genre_list, all_page_list, current_book):
    choices_as_string = []
    for i in range(0, len(all_book_list)):
        choices_as_string.append(str(i+1))
       
    print("\n")
    ask_user = input("Are you sure you want to remove a book from your library? Type Yes or No.\n")
    while ask_user not in ["yes", "YES", "Yes", "y", "Y", "no", "NO", "No", "n", "N"]:
       
        ask_user = input("Sorry, I do not understand.\nPlease enter Yes if you want to remove a book \nor No if you do not want to remove a book.\n")
       
    if ask_user == "yes" or ask_user == "Yes" or ask_user == "YES" or ask_user == "Y" or ask_user == "y":
   
        choice = input("Which book do you want to remove? Choose number: ")
       
        while choice not in (choices_as_string):
            choice = input("Invalid choice. Please try another number: ")

        choice = int(choice) - 1
        removed_book = all_book_list[choice]
        all_book_list.remove(removed_book)
        current_book = all_book_list[0]
        removed_author = all_author_list[choice]
        all_author_list.remove(removed_author)
        removed_genre = all_genre_list[choice]
        all_genre_list.remove(removed_genre)
        removed_page = all_page_list[choice]
        all_page_list.remove(removed_page)
        return all_book_list, all_author_list, all_genre_list, all_page_list, current_book
   
def get_books(filename):
    library_book_list = []
    library_author_list = []
    library_genre_list = []
    library_page_list = []
    trend_list = []
    programmer_reader_list = []
    detective_reader_list = []
    scary_reader_list = []
    shipments_list =[]
    book_series_list = []
   
    fileIn = open(filename, encoding='utf-8')
    fileIn.readline()
    reader = csv.reader(fileIn)
    x = 0
    for line in reader:
        if "Library" in line[0 : 5]:
            library_book_list.append(line[0])
            library_author_list.append(line[1].strip())
            library_genre_list.append(line[2].strip())
            library_page_list.append(line[3].strip())
        elif "Trending" in line[0 : 5]:
            trend_list.append(line[0 : 4])
        elif "Programming" in line [0 : 5]:
            programmer_reader_list.append(line[0 : 4])
        elif "Detective" in line[0 : 5]:
            detective_reader_list.append(line[0 : 4])
        elif "Scary" in line[0 : 5]:
            scary_reader_list.append(line[0 : 4])
        elif "Hardcover" in line[0 : 5]:
            shipments_list.append(line[0 : 4])
        elif "Series" in line[4]:
            book_series_list.append(line[0 : 5])
       
    fileIn.close()

    return library_book_list, library_author_list, library_genre_list, library_page_list, trend_list, programmer_reader_list, detective_reader_list, scary_reader_list, shipments_list, book_series_list
   

def main():
    date = datetime.datetime.today()

    menuItems = ['Check cart', 'Read different book from library', "View information on the book you're reading", 'Remove book from library', 'Learn about popular book series', 'Recommended Books', 'View your hardcover shipments', 'Exit']

    library_book_list, library_author_list, library_genre_list, library_page_list, trend_list, programmer_reader_list, detective_reader_list, scary_reader_list, shipments_list, book_series_list = get_books("books.csv")
    preferred_book = library_book_list[0]

    c = getMenuSelection(menuItems)
    while c != len(menuItems):

        if c == 1:
            fees_list = generate_costs(library_book_list)
            print_bill(library_book_list, fees_list, date)

        elif c == 2:
            print_all_books(preferred_book, library_book_list)
            preferred_book = change_preferred_book(library_book_list)

        elif c == 3:
##            author = get_author_name(all_library_books, preferred_book)
##            print_author_name(author)
##            genre = get_genre(all_library_books, preferred_book)
##            print_genre(genre)
            information = get_book_information(library_book_list, preferred_book)
            print_book_information(information, library_book_list, library_author_list, library_genre_list, library_page_list, preferred_book)

        elif c == 4:
            print_all_books(preferred_book, library_book_list)
            library_book_list, library_author_list, library_genre_list, library_page_list, preferred_book = remove_book(library_book_list, library_author_list, library_genre_list, library_page_list, preferred_book)
           
        elif c == 5:
            title_series_list, harry_potter_list, time_quintlet_list, percy_olympians_list, hunger_games_list = generate_series_list(book_series_list)
            series_titles_in_lists = list(divide_series_titles_in_lists(title_series_list))
            series_with_num_views = add_series_viewers(series_titles_in_lists)
            print_series(series_with_num_views)
            series_info, series_books_list = select_series_to_learn(title_series_list, series_with_num_views, harry_potter_list, time_quintlet_list, percy_olympians_list, hunger_games_list)
            print_series_books(series_info, series_books_list)

        elif c == 6:
            recommended_book_list = get_recommended_book_list(library_book_list, library_genre_list, preferred_book, programmer_reader_list, detective_reader_list, scary_reader_list)
            print_recommended_book_list(preferred_book, recommended_book_list)
            add_book(library_book_list, library_author_list, library_genre_list, library_page_list, recommended_book_list)

        elif c == 7:
            complete_shipments_list = generate_shipments_with_days(shipments_list)
            print_shipments(complete_shipments_list)
            alphabetize_shipments(complete_shipments_list)
           
           
        c = getMenuSelection(menuItems)
       

main()
